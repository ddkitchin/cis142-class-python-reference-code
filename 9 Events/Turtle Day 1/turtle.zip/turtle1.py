import turtle

WIN_WIDTH=300
WIN_HEIGHT=300
turtle.setup(WIN_WIDTH, WIN_HEIGHT)
win=turtle.Screen()

tim=turtle.Turtle()
tim.pencolor("red")
tim.circle(40)

win.mainloop()